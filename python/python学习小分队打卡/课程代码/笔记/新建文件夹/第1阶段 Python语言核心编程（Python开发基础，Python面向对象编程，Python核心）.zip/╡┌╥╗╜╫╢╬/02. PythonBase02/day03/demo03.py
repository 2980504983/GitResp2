"""
    固定集合
"""
set01 = frozenset([1,2,3,3,5])
list02 = list(set01)
print(set01)
print(list02)