"""
    str --> list
    练习:exercise08.py
"""

str01 = "张无忌-赵敏-周芷若"
list_result = str01.split("-")
print(list_result)


