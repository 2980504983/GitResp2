class DoubleListHelper:
    @staticmethod
    def helper():
        print("DoubleListHelper-helper")