print("模块1")

def fun01():
    print("模块1的fun01")

class MyClass02:
    def fun02(self):
        print("MyClass02--fun02")