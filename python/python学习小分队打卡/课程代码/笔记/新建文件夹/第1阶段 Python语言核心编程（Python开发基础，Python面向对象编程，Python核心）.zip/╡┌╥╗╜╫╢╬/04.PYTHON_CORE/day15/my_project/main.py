def main_fun01():
    print("main -- fun01")


from skill_system.skill_deployer import *

deploy()

# 语法：from 包 import *
# 依赖于在包的__init__.py文件中指定__all__ = [可导出的模块]
# from skill_system import *
# manager = skill_manager.SkillManager()
# manager.generate()


