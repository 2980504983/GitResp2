def deploy():
    print("skill_system--deploy")

from skill_system.skill_manager import *

manager = SkillManager()
manager.generate()