class SkillManager:
    def generate(self):
        print("skill_system--manager")


from common.double_list_helper import *

DoubleListHelper.helper()