def fun01():
    print("a -- fun01")