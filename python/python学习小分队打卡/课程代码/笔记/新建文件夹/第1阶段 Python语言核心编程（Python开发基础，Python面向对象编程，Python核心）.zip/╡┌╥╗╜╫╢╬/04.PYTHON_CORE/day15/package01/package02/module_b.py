def fun02():
    print("b -- fun02")


from package01.module_a import *
fun01()
