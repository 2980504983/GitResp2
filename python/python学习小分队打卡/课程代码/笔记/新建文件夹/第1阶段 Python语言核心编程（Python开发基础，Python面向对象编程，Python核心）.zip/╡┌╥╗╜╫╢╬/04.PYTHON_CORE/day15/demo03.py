"""
    包

python程序结构
    文件夹  ---- 项目根目录
        包
            模块
                类
                    函数
                        语句
    练习：my_project
"""

# # form 包.模块 import 成员
# from package01.module_a import fun01
# fun01()
#
# form 包.包.模块 import 成员
from package01.package02.module_b import fun02
fun02()

# import package01.module_a as pm
# pm.fun01()


