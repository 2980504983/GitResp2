"""
    str编码
    练习:exercise09.py
"""

# 字　－－> 数
num01 = ord("a")
print(num01)

# 数　－－> 字
str01 = chr(97)
print(str01)

