"""
    汇率转换器
"""

#1. 获取数据
str_usd = input("请输入美元：")
int_usd = int(str_usd)
#2. 逻辑处理
result = int_usd * 6.9
#3. 显示结果
print(result)

# 程序是改出来的
# 英文不好用有道
# 程序不是自上而下编写的
# 一行代码往往是从右向左写的