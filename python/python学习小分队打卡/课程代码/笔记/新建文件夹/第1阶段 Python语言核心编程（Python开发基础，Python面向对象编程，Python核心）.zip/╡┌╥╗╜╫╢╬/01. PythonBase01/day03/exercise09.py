# 练习1:在控制台中输出0 1 2 3 4 5
# 练习2:在控制台中输出2 3 4 5 6 7
# 练习3:在控制台中输出0 2 4 6


# count = 0
# while count < 6:
#     print(count)
#     count += 1

# count = 2
# while count < 8:
#     print(count)
#     count += 1

count = 0
while count <= 6:
    print(count)
    count += 2
