"""
    while 计数
    练习：exercise09.py
"""

# 需求:执行三次

count = 0
while count < 3:  # 0  1  2
    count += 1
    usd = int(input("请输入美元："))
    print(usd * 6.9)


